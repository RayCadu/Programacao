/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author user
 */
public class Motorista {
    
    private String numCNH;
    private String nome;
    private Data dtVenc;

    Motorista(String CNH, String nome, Data venc){
        this.numCNH = CNH;
        this.nome = nome;
        this.dtVenc = venc;
    }
    /**
     * @return the numCNH
     */
    public String getNumCNH() {
        return numCNH;
    }

    /**
     * @param numCNH the numCNH to set
     */
    public void setNumCNH(String numCNH) {
        this.numCNH = numCNH;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
     /**
     * @return the dtVenc
     */
    public Data getDtVenc() {
        return dtVenc;
    }

    /**
     * @param dtVenc the dtVenc to set
     */
    public void setDtVenc(Data dtVenc) {
        this.dtVenc = dtVenc;
    }
    
    public void salvarArq() throws IOException{
      FileWriter arq = new FileWriter("motoristas.txt", true);
      BufferedWriter buff = new BufferedWriter(arq);
      buff.write(this.numCNH + "\n");
      buff.write(this.nome + "\n");
      buff.write(this.dtVenc.getDia() + "\n");
      buff.write(this.dtVenc.getMes() + "\n");
      buff.write(this.dtVenc.getAno() + "\n");
      buff.close();
    }
}
