/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JFrame;

/**
 *
 * @author user
 */
public final class Sistema {
    
    private ArrayList<Motorista> motoristas;
    private ArrayList<Veiculo> veiculos;
    private ArrayList<Infracao> infracoes;
    private ArrayList<Natureza> naturezasInfra;
    
    Sistema() throws IOException{
        this.infracoes = new ArrayList<Infracao>();
        this.motoristas = new ArrayList<Motorista>();
        this.naturezasInfra = new ArrayList<Natureza>();
        this.veiculos = new ArrayList<Veiculo>();
        
        Natureza leve = new Natureza("leve", 3);
        this.naturezasInfra.add(leve);
        
        Natureza media = new Natureza("media", 4);
        this.naturezasInfra.add(media);
        
        Natureza grave = new Natureza("grave", 5);
        this.naturezasInfra.add(grave);
        
        Natureza gravissima = new Natureza("gravissima", 7);
        this.naturezasInfra.add(gravissima);
        
        try{
            this.lerMotoristas();
        } catch (FileNotFoundException ex){
            System.out.println("Aviso: Nenhum motorista carregado!");
        }
        
        try{
            this.lerVeiculos();
        } catch (FileNotFoundException ex){
            System.out.println("Aviso: Nenhum veiculo carregado!");
        }        
        
        
        try{
            this.lerInfracoes();
        } catch (FileNotFoundException ex){
            System.out.println("Aviso: Nenhuma infracao carregada!");
        }
        
        JFrame vf = new Cadastros(this.motoristas, this.infracoes, this.naturezasInfra, this.veiculos);
        vf.setVisible(true);
    }
    /**
     * @return the motoristas
     */
    public ArrayList<Motorista> getMotoristas() {
        return motoristas;
    }

    /**
     * @param motoristas the motoristas to set
     */
    public void setMotoristas(ArrayList<Motorista> motoristas) {
        this.motoristas = motoristas;
    }

    /**
     * @return the veiculos
     */
    public ArrayList<Veiculo> getVeiculos() {
        return veiculos;
    }

    /**
     * @param veiculos the veiculos to set
     */
    public void setVeiculos(ArrayList<Veiculo> veiculos) {
        this.veiculos = veiculos;
    }

    /**
     * @return the infracoes
     */
    public ArrayList<Infracao> getInfracoes() {
        return infracoes;
    }

    /**
     * @param infracoes the infracoes to set
     */
    public void setInfracoes(ArrayList<Infracao> infracoes) {
        this.infracoes = infracoes;
    }

    /**
     * @return the naturezasInfra
     */
    public ArrayList<Natureza> getNaturezasInfra() {
        return naturezasInfra;
    }

    /**
     * @param naturezasInfra the naturezasInfra to set
     */
    public void setNaturezasInfra(ArrayList<Natureza> naturezasInfra) {
        this.naturezasInfra = naturezasInfra;
    }
    
    public void lerInfracoes() throws FileNotFoundException, IOException{
        FileReader arq = new FileReader("infracoes.txt");
        BufferedReader buf = new BufferedReader(arq);
        
        Veiculo vei = null;
        Motorista mot = null;
        Natureza nat = null;
        
        while(buf.ready()){
            String codigo = buf.readLine();
            int dia = Integer.parseInt(buf.readLine());
            int mes = Integer.parseInt(buf.readLine());
            int ano = Integer.parseInt(buf.readLine());
            Data d1 = new Data(dia, mes, ano);
            String placa = buf.readLine();
            
            for(Veiculo v : this.veiculos){
                if(v.getPlaca().equals(placa)){
                    vei = v;
                }
            }
            String cnh = buf.readLine();
            for(Motorista m : this.motoristas){
                if(m.getNumCNH().equals(cnh)){
                    mot = m;
                }
            }            
            String natInfra = buf.readLine();
            for(Natureza n : this.naturezasInfra){
                if(n.getTpInfracao().equals(natInfra)){
                    nat = n;
                }
            }
            Infracao infra = new Infracao(codigo, d1, vei, mot, nat);
            this.infracoes.add(infra);
        }
    }
    
    public void lerMotoristas() throws FileNotFoundException, IOException{
       FileReader arq = new FileReader("motoristas.txt");
       BufferedReader buff = new BufferedReader(arq); 
       
       while(buff.ready()){
           String numCNH = buff.readLine();
           String nome = buff.readLine();
           int dia = Integer.parseInt(buff.readLine());
           int mes = Integer.parseInt(buff.readLine());
           int ano = Integer.parseInt(buff.readLine());
           Data d1 = new Data(dia, mes, ano);
           
           Motorista mot = new Motorista(numCNH, nome, d1);
           this.motoristas.add(mot);          
       }
    }
    
    public void lerVeiculos() throws FileNotFoundException, IOException{
       FileReader arq = new FileReader("veiculos.txt");
       BufferedReader buff = new BufferedReader(arq); 
       Motorista moto = null;
       while(buff.ready()){
           String placa = buff.readLine();
           String cnh = buff.readLine();
           for(Motorista m : this.motoristas){
               if(m.getNumCNH().equals(cnh)){
                   moto = m;
               }
           }
           String modelo = buff.readLine();
           String cor = buff.readLine();
           
           Veiculo vei = new Veiculo(placa, moto, modelo, cor);
           this.veiculos.add(vei);
       }    
    }
}
