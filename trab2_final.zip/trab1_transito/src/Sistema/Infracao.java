/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Infracao {
    private String codigo;
    private Data dtOcorrencia;
    private Veiculo veiculo;
    private Motorista condutor = null;
    private Natureza natInfracao;
    
    Infracao(String codigo, Data dtOcorrencia, Veiculo veiculo, Motorista condutor, Natureza natInfracao){
        this.codigo = codigo;
        this.condutor = condutor; // ou this.condutor = null;
        this.dtOcorrencia = dtOcorrencia;
        this.natInfracao = natInfracao;
        this.veiculo = veiculo;
    }

    Infracao() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    /**
     * @return the codigo
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the dtOcorrencia
     */
    public Data getDtOcorrencia() {
        return dtOcorrencia;
    }

    /**
     * @param dtOcorrencia the dtOcorrencia to set
     */
    public void setDtOcorrencia(Data dtOcorrencia) {
        this.dtOcorrencia = dtOcorrencia;
    }

    /**
     * @return the veiculo
     */
    public Veiculo getVeiculo() {
        return veiculo;
    }

    /**
     * @param veiculo the veiculo to set
     */
    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    /**
     * @return the condutor
     */
    public Motorista getCondutor() {
        return condutor;
    }

    /**
     * @param condutor the condutor to set
     */
    public void setCondutor(Motorista condutor) {
        this.condutor = condutor;
    }

    /**
     * @return the natInfracao
     */
    public Natureza getNatInfracao() {
        return natInfracao;
    }

    /**
     * @param natInfracao the natInfracao to set
     */
    public void setNatInfracao(Natureza natInfracao) {
        this.natInfracao = natInfracao;
    }
    
    public void salvarArq() throws IOException{
        FileWriter arq = new FileWriter("infracoes.txt", true);
        BufferedWriter buff = new BufferedWriter(arq);
        buff.write(this.codigo + "\n");
        buff.write(this.dtOcorrencia.getDia() + "\n");
        buff.write(this.dtOcorrencia.getMes() + "\n");
        buff.write(this.dtOcorrencia.getAno() + "\n");
        buff.write(this.veiculo.getPlaca() + "\n");
        buff.write(this.condutor.getNumCNH()+ "\n");
        buff.write(this.natInfracao.getTpInfracao() + "\n");
        buff.close();
    }
    
    public void salvarArqMudado(ArrayList<Infracao> infracoes) throws IOException{
        FileWriter arq = new FileWriter("infracoes.txt");
        BufferedWriter buff = new BufferedWriter(arq);
        for(Infracao ni: infracoes){
            buff.write(ni.codigo + "\n");
            buff.write(ni.dtOcorrencia.getDia() + "\n");
            buff.write(ni.dtOcorrencia.getMes() + "\n");
            buff.write(ni.dtOcorrencia.getAno() + "\n");
            buff.write(ni.veiculo.getPlaca() + "\n");
            buff.write(ni.condutor.getNumCNH()+ "\n");
            buff.write(ni.natInfracao.getTpInfracao() + "\n");
        }
        buff.close();
    }
}
