/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author user
 */
public class Data {
    
    private int dia;
    private int mes;
    private int ano;
    
    Data(int dia, int mes, int ano){
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }
    
    Data(){}
    
    /**
     * @return the dia
     */
    public int getDia() {
        return dia;
    }

    /**
     * @param dia the dia to set
     */
    public void setDia(int dia) {
        this.dia = dia;
    }

    /**
     * @return the mes
     */
    public int getMes() {
        return mes;
    }

    /**
     * @param mes the mes to set
     */
    public void setMes(int mes) {
        this.mes = mes;
    }

    /**
     * @return the ano
     */
    public int getAno() {
        return ano;
    }

    /**
     * @param ano the ano to set
     */
    public void setAno(int ano) {
        this.ano = ano;
    }
    
    public String getDateTime() {
	DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	Date date = new Date();
	return dateFormat.format(date);
    }
    
    public String dateTOstring(){
        return Integer.toString(this.dia) + "/" + Integer.toString(this.mes) + "/" + Integer.toString(this.ano);
    }

    public boolean TempoDec(){
        String dataHj = getDateTime();
        Integer dia = Integer.parseInt(dataHj.substring(0,2));
        Integer mes = Integer.parseInt(dataHj.substring(3,5));
        Integer ano = Integer.parseInt(dataHj.substring(6,10));
        
        if(this.ano == ano) return true;
        else{ //12/12/2021
            if(this.ano == ano - 1){
                if(this.mes == mes){
                    if(this.dia >= dia){
                        return true;
                    }
                }
                
                if(this.mes > mes){
                    return true;
                }
            }
        }
        return false;
    }
}
