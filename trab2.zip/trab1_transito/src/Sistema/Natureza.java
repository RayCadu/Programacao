/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

/**
 *
 * @author user
 */
class Natureza {
    
    private String tpInfracao;
    private int pontuacao;
    
    Natureza(String tpInfracao, int pontuacao){
        this.tpInfracao = tpInfracao;
        this.pontuacao = pontuacao;
    }
    /**
     * @return the tpInfracao
     */
    public String getTpInfracao() {
        return tpInfracao;
    }

    /**
     * @param tpInfracao the tpInfracao to set
     */
    public void setTpInfracao(String tpInfracao) {
        this.tpInfracao = tpInfracao;
    }

    /**
     * @return the pontuacao
     */
    public int getPontuacao() {
        return pontuacao;
    }

    /**
     * @param pontuacao the pontuacao to set
     */
    public void setPontuacao(int pontuacao) {
        this.pontuacao = pontuacao;
    }
}
