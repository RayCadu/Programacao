/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sistema;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author user
 */
public class Veiculo {
    
    private String placa;
    private Motorista proprietario;
    private String modelo;
    private String cor;
    
    Veiculo(String placa, Motorista proprietario, String modelo, String cor){
        this.placa = placa;
        this.proprietario = proprietario;
        this.modelo = modelo;
        this.cor = cor;
    }
    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * @return the proprietario
     */
    public Motorista getProprietario() {
        return proprietario;
    }

    /**
     * @param proprietario the proprietario to set
     */
    public void setProprietario(Motorista proprietario) {
        this.proprietario = proprietario;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the cor
     */
    public String getCor() {
        return cor;
    }

    /**
     * @param cor the cor to set
     */
    public void setCor(String cor) {
        this.cor = cor;
    }
    
    public void salvarArq() throws IOException{
        FileWriter arq = new FileWriter("veiculos.txt", true);
        BufferedWriter buff = new BufferedWriter(arq);
        buff.write(this.placa + "\n");
        buff.write(this.proprietario.getNumCNH() + "\n");
        buff.write(this.modelo + "\n");
        buff.write(this.cor + "\n");
        buff.close();
    }

}
